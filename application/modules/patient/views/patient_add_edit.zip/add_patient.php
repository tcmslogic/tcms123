<script type="text/javascript">
  $(function() {
    $( "#date_of_birth" ).datepicker();
	
  });
  $(function() {
    $( "#date_of_admission" ).datepicker();
	
  });

function check_nric_no(nric_no){
	$.ajax({
		type:'POST',
		url:'check_nric_no?nric='+nric_no,
		success:function(data){
			if(data=='no'){
				$('#nric_passport').val('');
				$('#error_nric').html('This No. '+nric_no+' Already Exist!');
				$('#error_nric').css( "color","red" );
			}else{
				$('#error_nric').html('This No. '+nric_no+' Not Exist!');
				$('#error_nric').css( "color","green" );
			}
		}
	});	
}

$(document).ready(function(){
	$("#add_patinent").validationEngine();
	
	/*html2canvas([document.getElementById('container')], {
		onrendered: function (canvas) {
		var data = canvas.toDataURL('image/png');
		$("#imgbase64").val(data);
		//alert(data);
		}
	 });*/
	
	/*$("#submit").mouseover(function(e) {
		html2canvas([document.getElementById('container')], {
			onrendered: function (canvas) {
			var data = canvas.toDataURL('image/png');
			$("#imgbase64").val(data);
			//alert(data);
			}
		 });
			
	});*/
	/*$( "#add_patinent" ).submit(function( event ) {
		var numItems = $('.formErrorContent').length;
		if(numItems==0){
			html2canvas([document.getElementById('container')], {
			onrendered: function (canvas) {
			var data = canvas.toDataURL('image/png');
			$("#imgbase64").val(data);
			}
		 });
		//event.preventDefault();
		}
		
	});*/
	
	/*$("#submit").mouseover(function(event) {
		//event.preventDefault();
		goToByScroll('submit_btn'); 
		html2canvas([document.getElementById('container')], {
			onrendered: function (canvas) {
			var data = canvas.toDataURL('image/png');
			$("#imgbase64").val(data);
			//alert(data);
			//event.preventDefault();
			//return false;
			}
		 });
		//event.preventDefault();
		//return false;
	});*/
});


</script>
	
<?php
$ref_number = $this->mdl_patient->get_ref_number();
//print_r($ref_number);
?>	


<div id="Clinica_right">
    <div id="top_border">
      <div id="left_title">
        <h2>Add  New Patient </h2>
      </div>
    </div>
    <form name="add_patinent" id="add_patinent" action="<?php echo site_url("patient/add_patient");?>" method="post" enctype="multipart/form-data" onsubmit="return checkValid();">
	
    <div id="Patient_table">
      <div id="Personal_Details">
        <div id="Personal_title_data"><label>Reference No. <?php echo $ref_number;?></label> </div>

        <div id="Personal_title_data">
        
            <div id="First_Name"><span>Surname</span>
              <input type="text" name="sur_name" id="sur_name" class="validate[required] text-input"  />
            </div>
            
              <div id="First_Name"><span>Given Name</span>
                  <input type="text" name="given_name" id="given_name" class="validate[required] text-input"  />
              </div>
        </div>
        
        <div id="Personal_title_data">
          <div id="First_Name"><span>NRIC No/Passport*</span>
              <input type="text" name="nric_passport" id="nric_passport" onblur="return check_nric_no(this.value);" class="validate[required] text-input" />
              <input type="hidden" name="ref_no" value="<?php echo $ref_number;?>" id="ref_no" />
              <div id="error_nric" style="text-align:right;"></div>
          </div>
          
          <div id="First_Name"> <span>Date of  Birth </span>
               <input class="text-input" type="text" name="date_of_birth" id="date_of_birth"  />
            </div>
          
        </div>
       
        <div id="Personal_title_data">
            <div id="First_Name">
            <span>Gender</span>
            <div id="First_Name" style="margin-right:15px;"> 
              <div id="sw_filt">
               <input type="radio" name="gender" id="male" value="male" checked="checked" />
                <label for="nofilt">Male</label>
               <input type="radio" name="gender" id="female" value="female"/>
                <label for="regionfilt">Female</label>
              </div>
            </div>
            </div>
            
            <div id="First_Name"> <span>Age</span>
               <input class="text-input" type="text" name="age" id="age" />
             </div>
         
         </div>   
        
        <div id="Personal_title_data">
            <div id="First_Name"> <span>Profession</span>
               <input class="text-input" type="text" name="profession" id="profession" />
            </div>
            
            <div id="First_Name"> <span>Mailing Address</span>
           		<input class="validate[required,email] text-input" type="text" name="email" id="email" />
        	</div>
            
        </div>
        
        <div id="Personal_title_data">
        	<div id="First_Name"> <span>Office</span>
           		<input class="text-input" type="text" name="office_no" id="office_no"  />
          	</div>
            
            <div id="First_Name"> <span>Home</span>
           		 <input class="text-input" type="text" name="home_no" id="home_no"  />
          	</div>
            
        </div>
       
        <div id="Personal_title_data">
             <div id="First_Name"> <span>Mobile</span>
               <input class="text-input" type="text" name="mobile_no" id="mobile_no"  />
              </div>
              
              <div id="First_Name"> <span>Dataed On</span>
        	   <input class="text-input" type="text" name="date_of_admission" id="date_of_admission"  />
          	</div>
        </div>
        
        <div id="Personal_title_data">
        	<div id="First_Name"> <label>PATIENTS DESCRIPTION IS ADVISED</label>
          	 <div id="first">
             <textarea class="text-input" name="description" id="description" cols="83" rows="5"></textarea>
             </div>
          	</div>
        </div>
        
        <div id="Personal_title_data">
        <label>A Are you allergic to any medicine / food?</label>
            <div id="sw_filt">
                <input type="radio" name="allergic" value="1" />
                <label for="nofilt">Yes</label>
                <input type="radio" name="allergic" value="0"/>
                <label for="regionfilt">No</label>
            </div>
            <div id="First_Name"> <label>Give Details</label>
          	 <div id="first">
             <textarea class="text-input" name="allergic_details" id="allergic_details" cols="83" rows="2"></textarea>
             </div>
          	</div>
        </div>
        
        <div id="Personal_title_data">
        <label>B Have You had previous surgery?</label>
            <div id="sw_filt">
                <input type="radio" name="previous_surgery" value="1" />
                <label for="nofilt">Yes</label>
                <input type="radio" name="previous_surgery" value="0"/>
                <label for="regionfilt">No</label>
            </div>
            <div id="First_Name"> <label>Give Details</label>
          	 <div id="first">
             <textarea class="text-input" name="previous_surgery_details" id="previous_surgery_details" cols="83" rows="2"></textarea>
             </div>
          	</div>
        </div>
        
        <div id="Personal_title_data">
        <label>C Mark "O and X" on the diagram for the affected lesion on the body:</label>
            <div id="sw_filt" class="marking">
                <input type="radio" name="marking" value="marko" />
                <label for="nofilt">Mark O</label>
                <input type="radio" name="marking" value="markx"/>
                <label for="regionfilt">Mark X</label>
                <input type="radio" name="marking" value="removemark"/>
                <label for="removemark">Remove Mark</label>
            </div>
            <div id="First_Name">
            <div id="img_demo">
          	 <div id="container">
              <img alt="" width="600" height="300" title="" src="<?php echo base_url(); ?>assets/default/img/patient_body.jpg"> 
            </div>
            </div>
          	</div>
        </div>
        <input type="hidden" name="marking_img" value="" id="imgbase64" />
        
        <div id="Personal_title_data">
            <div id="First_Name"> <label>D Chief Complaint</label>
          	 <div id="first">
             <textarea class="text-input" name="chief_complaint" id="chief_complaint" cols="83" rows="2"></textarea>
             </div>
          	</div>
        </div>
        
         <div id="Personal_title_data">
            <div id="First_Name"> <label>E History of Present Illness</label>
          	 <div id="first">
             <textarea class="text-input" name="present_illness" id="present_illness" cols="83" rows="2"></textarea>
             </div>
          	</div>
        </div>
        
         <div id="Personal_title_data">
            <div id="First_Name"> <label>F Past Madication History</label>
          	 <div id="first">
             <textarea class="text-input" name="past_medication" id="past_medication" cols="83" rows="2"></textarea>
             </div>
          	</div>
        </div>
      
        <div id="Personal_title_data">
            <div id="First_Name"> <label>G Physical Examination</label>
          	 <div id="first">
             <textarea class="text-input" name="physical_exam" id="physical_exam" cols="83" rows="2"></textarea>
             </div>
          	</div>
        </div>
        
        <div id="Personal_title_data">
            <div id="First_Name"> <label>H Impression Disease With</label>
          	 <div id="first">
             <textarea class="text-input" name="disease" id="disease" cols="83" rows="2"></textarea>
             </div>
          	</div>
        </div>
        
        <div id="Personal_title_data">
        <label>I Habits/Familial Hx</label>
            <div id="sw_filt">
                <input type="checkbox" name="smoking" value="1" />
                <label for="nofilt">Smoking</label>
                <input type="checkbox" name="alcohol" value="1"/>
                <label for="regionfilt">Alcohol</label>
                <input type="checkbox" name="drug_abuse" value="1"/>
                <label for="regionfilt">Drug Abuse</label>
                <input type="checkbox" name="familial_hx" value="1"/>
                <label for="regionfilt">Familial Hx</label>
                <input type="checkbox" name="hair_perm" value="1"/>
                <label for="regionfilt">Hair Perm</label>
                 <input type="checkbox" name="hair_color" value="1"/>
                <label for="regionfilt">Hair Color</label>
                <input type="checkbox" name="contraceptive" value="1"/>
                <label for="regionfilt">Contraceptive</label>
            </div>
        </div>

</div>

    <div id="button_save" style="clear:left; position:relative;">
        <div id="submit" >
        <input type="submit" name="submit" id="submit_btn" value="submit" />
        </div>
         <div id="button_Cancel"><a href="<?php echo site_url('patient/'); ?>" >Cancel</a></div>
      </div>
  
</div>
</form>

</div>

